#!/bin/bash
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_0.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_0.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_1.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_1.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_2.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_2.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_3.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_3.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_4.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_4.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_5.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_5.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_6.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_6.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_7.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_7.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_8.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_8.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_9.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_9.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_10.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_10.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_11.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_11.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_12.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_12.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_13.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_13.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_14.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_14.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_15.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_15.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_16.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_16.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_17.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_17.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_18.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_18.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_19.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_19.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_20.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_20.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_21.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_21.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_22.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_22.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_23.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_23.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_24.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_24.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_25.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_25.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_26.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_26.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_27.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_27.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_28.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_28.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_29.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_29.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_30.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_30.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_31.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_31.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_32.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_32.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_33.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_33.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_34.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_34.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_35.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_35.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_36.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_36.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_37.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_37.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_38.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_38.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_39.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_39.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_40.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_40.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_41.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_41.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_42.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_42.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_43.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_43.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_44.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_44.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_45.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_45.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_46.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_46.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_47.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_47.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_48.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_48.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_49.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_49.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_50.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_50.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_51.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_51.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_52.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_52.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_53.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_53.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_54.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_54.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_55.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_55.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_56.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_56.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_57.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_57.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_58.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_58.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_59.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_59.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_60.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_60.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_61.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_61.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_62.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_62.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_63.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_63.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_64.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_64.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_65.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_65.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_66.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_66.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_67.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_67.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_68.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_68.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_69.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_69.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_70.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_70.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_71.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_71.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_72.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_72.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_73.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_73.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_74.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_74.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_75.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_75.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_76.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_76.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_77.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_77.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_78.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_78.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_79.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_79.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_80.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_80.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_81.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_81.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_82.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_82.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_83.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_83.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_84.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_84.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_85.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_85.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_86.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_86.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_87.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_87.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_88.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_88.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_89.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_89.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_90.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_90.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_91.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_91.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_92.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_92.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_93.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_93.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_94.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_94.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_95.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_95.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_96.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_96.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_97.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_97.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_98.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_98.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
CUDA_VISIBLE_DEVICES=0 python evaluator.py --subnet search-cifar10-mbv3-w1.0/iter_0/net_99.subnet --data ../data/cifar10 --dataset cifar10 --n_classes 10 --supernet ofa_mbv3_d234_e346_k357_w1.0 --pretrained --save search-cifar10-mbv3-w1.0/iter_0/net_99.stats --trn_batch_size 128 --vld_batch_size 200 --num_workers 0 --n_epochs 5 --resolution 224 --valid_size 5000 --reset_running_statistics &
wait
